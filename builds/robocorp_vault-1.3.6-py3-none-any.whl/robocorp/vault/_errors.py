class RobocorpVaultError(RuntimeError):
    """Raised when there's problem with reading from Robocorp Vault."""

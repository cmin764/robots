from typing import Tuple

UNSCOPED_ELEMENTS: Tuple[str, ...] = (
    "UNTRACKED_GENERATOR",
    "IF",
    "ELSE",
    "ASSERT_FAILED",
    "BREAK",
    "CONTINUE",
)

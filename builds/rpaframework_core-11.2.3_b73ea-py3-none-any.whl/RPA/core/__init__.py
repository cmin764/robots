from .certificates import use_system_certificates


use_system_certificates()
